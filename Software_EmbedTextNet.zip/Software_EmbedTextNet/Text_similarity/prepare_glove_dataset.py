import numpy as np
Glove = {}
f = open('./glove.6B.300d.txt') 

print("Loading Glove vectors.")
for line in f:
    values = line.split()
    word = values[0]
    coefs = np.asarray(values[1:], dtype='float32')
    Glove[word] = coefs
f.close()

X_train = []
X_train_names = []
for x in Glove:
        X_train.append(Glove[x])
        X_train_names.append(x)
X_train = np.asarray(X_train)

np.save('./Data_EmbedTextNet/Glove/train_data_glove_300d', X_train) 
np.save('./Data_EmbedTextNet/Glove/test_data_glove_300d', X_train) 
np.save('./Data_EmbedTextNet/Glove/test_txt_glove_300d', X_train_names)

Glove = {}
f = open('./glove.6B.50d.txt') 

print("Loading Glove vectors.")
for line in f:
    values = line.split()
    word = values[0]
    coefs = np.asarray(values[1:], dtype='float32')
    Glove[word] = coefs
f.close()

X_train = []
X_train_names = []
for x in Glove:
        X_train.append(Glove[x])
        X_train_names.append(x)
X_train = np.asarray(X_train)

np.save('./Data_EmbedTextNet/Glove/train_data_glove_50d', X_train) 
np.save('./Data_EmbedTextNet/Glove/test_data_glove_50d', X_train) 
np.save('./Data_EmbedTextNet/Glove/test_txt_glove_50d', X_train_names)