from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import numpy as np
import argparse, umap

def pca(train_embed, test_embed, target_dim):

  sc = StandardScaler()
  X_train = sc.fit_transform(train_embed)
  X_test = sc.transform(test_embed)

  pca =  PCA(n_components = target_dim)
  X_train = pca.fit_transform(X_train)
  dim_reduc_embed = pca.transform(X_test)


  return dim_reduc_embed

def algo(train_embed, test_embed, target_dim):

  # PCA to get Top Components
  pca =  PCA(n_components = train_embed.shape[1])
  X_train = train_embed - np.mean(train_embed)
  X_fit = pca.fit_transform(X_train)
  U1 = pca.components_

  z = []

  # Removing Projections on Top Components
  for i, x in enumerate(X_train):
    for u in U1[0:7]:        
            x = x - np.dot(u.transpose(),x) * u 
    z.append(x)

  z = np.asarray(z)

  # PCA Dim Reduction∑
  pca =  PCA(n_components = target_dim)
  X_train = z - np.mean(z)
  X_train_new_final = pca.fit_transform(X_train)
  X_new_final = pca.transform(test_embed)

  # PCA to do Post-Processing Again
  pca =  PCA(n_components = target_dim)
  X_new = X_train_new_final - np.mean(X_train_new_final)
  X_train_new = pca.fit_transform(X_new)
  X_new = pca.transform(X_new_final)
  Ufit = pca.components_

  X_new_final = X_new_final - np.mean(X_new_final)


  for i in range(len(X_new_final)):
    for u in Ufit[0:7]:
      X_new_final[i] = X_new_final[i] - np.dot(u.transpose(), X_new_final[i]) * u 

  dim_reduc_embed = X_new_final

  return dim_reduc_embed

# Require !pip install umap-learn

def umap_fun(train_embed, test_embed, target_dim):

  trans = umap.UMAP(n_neighbors=15, n_components=target_dim, metric='euclidean').fit(train_embed) # euclidean
  dim_reduc_embed = trans.transform(test_embed)

  return dim_reduc_embed



def main(args):
  train_embed = np.load(args.train_embed)
  test_embed = np.load(args.test_embed)
  test_txt = np.load(args.test_txt)

  if args.methods == 'pca':
    dim_reduc_embed = pca(train_embed, test_embed, args.target_dim)

  elif args.methods == 'algo':

    dim_reduc_embed = algo(train_embed, test_embed, args.target_dim)

  elif args.methods == 'umap':

    dim_reduc_embed = umap_fun(train_embed, test_embed, args.target_dim)

  else:
    print('Wrong baseline methods. Please try one of pca / algo / umap')


  if args.target_txt == 'word':
    tmp_embeddings = {}
    embedding_file = open('reduced_embedding.txt', 'w')
    for i, x in enumerate(test_txt):
      tmp_embeddings[x] = dim_reduc_embed[i]
      embedding_file.write("%s\t" % x)
      for t in tmp_embeddings[x]:
        embedding_file.write("%f\t" % t)        
      embedding_file.write("\n")

    embedding_file.close()

  else:
    test_dict = {}
    loc = 0
    for sent in test_txt:
      if sent not in test_dict.keys():
        test_dict[sent] = [dim_reduc_embed[loc]]
      else:
        if args.target_txt == 'sentence': # same sentence can give different embeddings from pre-trained Sentence-BERTs.
          test_dict[sent].append(dim_reduc_embed[loc])
      loc +=1 

    np.save('reduced_embedding', test_dict) # when load, np.load('reduced_embedding.npy', allow_pickle=True).item()

if __name__=="__main__":
  parser = argparse.ArgumentParser(
      description='Dimension Reduction with Baseline methods',
      formatter_class=argparse.ArgumentDefaultsHelpFormatter)
  parser.add_argument('--train-embed', type=str, required=True, help='Embedding of train set.')       
  parser.add_argument('--test-embed', type=str, required=True, help='Embedding of test set.')
  parser.add_argument('--test-txt', type=str, required=True, help='Text of test set.')    
  
  parser.add_argument('--target-txt', type=str, required=True, help='Choose applications: word / sentence / msetence (multilingual sentence).')
  parser.add_argument('--target-dim', type=int, required=True, help='Target reduced dimension.')

  parser.add_argument('--methods', type=str, required=True, help='Choose baseline methods: pca / algo / umap.')

  args = parser.parse_args()
  main(args)