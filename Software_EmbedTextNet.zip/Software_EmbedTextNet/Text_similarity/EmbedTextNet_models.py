
import numpy as np
import matplotlib.pyplot as plt
import time, scipy.io, argparse
from random import random
from sklearn.model_selection import train_test_split
from keras import backend as K
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, regularizers


class Sampling(layers.Layer):
  def call(self, data):
      z_mean, z_log_var = data
      size = tf.shape(z_mean)[0]
      dim = tf.shape(z_mean)[1]
      epsilon = K.random_normal(shape=(size, dim))
      return z_mean + tf.exp(0.5 * z_log_var) * epsilon

class EMBEDTEXTNETModel:

  def __init__(self, train_embed, target_txt, target_dim, epoch=30, batch_size=32, learning_rate=2e-3, corr_thres=5):

    self.train_embed = train_embed

    self.target_txt = target_txt
    self.target_dim = target_dim

    self.epochs = epoch
    self.batch_size = batch_size
    self.learning_rate = learning_rate
    self.corr_thres = corr_thres

    self.original_dim = self.train_embed.shape[1]

    self.encoder = self.make_encoder_model(self.target_txt, self.target_dim, self.original_dim)
    self.decoder = self.make_decoder_model(self.target_txt, self.target_dim, self.original_dim)

    self.encoder_optimizer = tf.keras.optimizers.RMSprop(learning_rate=self.learning_rate)
    self.decoder_optimizer = tf.keras.optimizers.RMSprop(learning_rate=self.learning_rate)


  def make_encoder_model(self, target_txt, target_dim, original_dim):

    encoder_inputs = keras.Input(shape=(original_dim, 1, 1))

    if target_txt == 'word':
      print('Build Encoder for word embedding')
      second_avg_pool = 5  # Glove 300d -> 50d or Glove 50d -> 10d
      if original_dim == 300 and (target_dim == 150 or 100):
        second_avg_pool = 3 # Glove 300d -> 150d or 100d
              
      x = layers.Conv2D(32, (5, 1), strides=(1, 1), padding="same")(encoder_inputs)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.AveragePooling2D((2, 1), padding='same')(x)
      x = layers.Conv2D(64, (5, 1), strides=(1, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.AveragePooling2D((second_avg_pool, 1), padding='same')(x)
      x = layers.Conv2D(128, (5, 1), strides=(1, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.Flatten()(x)
      x = layers.Dense(target_dim)(x)

      z_mean = layers.Dense(target_dim, name="z_mean")(x)
      z_log_var = layers.Dense(target_dim, name="z_log_var")(x)
      z = Sampling()([z_mean, z_log_var])

      encoder = keras.Model(encoder_inputs, [z_mean, z_log_var, z], name="encoder")
      
      return encoder

    elif target_txt == 'sentence':
      print('Build Encoder for sentence embedding')
      x = layers.Conv2D(32, (5, 1), strides=(1, 1), padding="same")(encoder_inputs)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.AveragePooling2D((4, 1), padding='same')(x)
      x = layers.Conv2D(64, (5, 1), strides=(1, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.AveragePooling2D((4, 1), padding='same')(x)
      x = layers.Conv2D(128, (5, 1), strides=(1, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.Flatten()(x)
      x = layers.Dense(target_dim)(x)

      z_mean = layers.Dense(target_dim, name="z_mean")(x)
      z_log_var = layers.Dense(target_dim, name="z_log_var")(x)
      z = Sampling()([z_mean, z_log_var])

      encoder = keras.Model(encoder_inputs, [z_mean, z_log_var, z], name="encoder")
      
      return encoder

    elif target_txt == 'msentence':
      print('Build Encoder for multilingual sentence embedding')   
      x = layers.Conv2D(32, (5, 1), strides=(1, 1), padding="same")(encoder_inputs)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.AveragePooling2D((2, 1), padding='same')(x)
      x = layers.Conv2D(64, (5, 1), strides=(1, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.AveragePooling2D((4, 1), padding='same')(x)
      x = layers.Conv2D(128, (5, 1), strides=(1, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.Flatten()(x)
      x = layers.Dense(target_dim)(x)

      z_mean = layers.Dense(target_dim, name="z_mean")(x)
      z_log_var = layers.Dense(target_dim, name="z_log_var")(x)
      z = Sampling()([z_mean, z_log_var])

      encoder = keras.Model(encoder_inputs, [z_mean, z_log_var, z], name="encoder")

      return encoder

    else:
      print('Wrong target texts. Please try one of word / sentence / msentence')


  def make_decoder_model(self, target_txt, target_dim, original_dim):
    latent_inputs = keras.Input(shape=(target_dim,))

    if target_txt == 'word':
      print('Build Decoder for word embedding') 
      x = layers.Dense(original_dim * 1 * 128, activation='relu')(latent_inputs) 
      x = layers.Reshape((original_dim, 1, 128))(x) 
      x = layers.Conv2DTranspose(128, (5, 1), strides=(1, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.Conv2DTranspose(64, (5, 1), strides=(1, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.Conv2DTranspose(32, (5, 1), strides=(1, 1), padding="same")(x)
      decoder_outputs = layers.Conv2DTranspose(1, (5, 1), padding="same")(x)

      decoder = keras.Model(latent_inputs, decoder_outputs, name="decoder")

      return decoder


    elif target_txt == 'sentence':
      print('Build Decoder for sentence embedding') 
      x = layers.Dense(128 * 1 * 128, activation='relu')(latent_inputs) 
      x = layers.Reshape((128, 1, 128))(x) 
      x = layers.Conv2DTranspose(128, (5, 1), strides=(2, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.Conv2DTranspose(64, (5, 1), strides=(2, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.Conv2DTranspose(32, (5, 1), strides=(2, 1), padding="same")(x)
      decoder_outputs = layers.Conv2DTranspose(1, (5, 1), padding="same")(x)

      decoder = keras.Model(latent_inputs, decoder_outputs, name="decoder")
     
      return decoder

    elif target_txt == 'msentence':
      print('Build Decoder for multilingual sentence embedding')   
      x = layers.Dense(96 * 1 * 128, activation='relu')(latent_inputs) 
      x = layers.Reshape((96, 1, 128))(x) 
      x = layers.Conv2DTranspose(128, (5, 1), strides=(2, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.Conv2DTranspose(64, (5, 1), strides=(2, 1), padding="same")(x)
      x = layers.BatchNormalization()(x)
      x = layers.LeakyReLU()(x)
      x = layers.Conv2DTranspose(32, (5, 1), strides=(2, 1), padding="same")(x)
      decoder_outputs = layers.Conv2DTranspose(1, (5, 1), padding="same")(x)

      decoder = keras.Model(latent_inputs, decoder_outputs, name="decoder")

      return decoder 

    else:
      print('Wrong target texts. Please try one of word / sentence / msentence')

  def EMBEDTEXTNET_train(self):

    if self.target_txt == 'word':
      split_rate = 0.2
    else:
      split_rate = 0.1

    train_set, val_set = train_test_split(self.train_embed, test_size=split_rate)
    train_set = np.reshape(train_set, [train_set.shape[0], train_set.shape[1], 1, 1])
    val_set = np.reshape(val_set, [val_set.shape[0], val_set.shape[1], 1, 1])

    train_set = tf.data.Dataset.from_tensor_slices(train_set).batch(self.batch_size)
    val_set = tf.data.Dataset.from_tensor_slices(val_set).batch(self.batch_size)


    EPOCH = self.epochs + 1 # Additional one epoch for calcuating the weight value in EmbedTextNet
    CORR_THRES = self.corr_thres + 1 # # When CorrelationLoss is applied

    print('Learning Started!')
    start_time = time.time()

    vae_t_loss, vae_r_loss, vae_kl_loss, vae_c_loss, vae_val_t_loss, vae_val_r_loss, vae_val_kl_loss, vae_val_c_loss = self.train(train_set, val_set, EPOCH, CORR_THRES)

    print('Learning Finished!')
    print('Building time for EmbedTextNet: {:.2f} seconds'.format(time.time()-start_time))
    
    plt.figure(1)
    plt.title('Total Loss')
    plt.plot(vae_t_loss, label='Train loss')
    plt.plot(vae_val_t_loss, label='Val loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()      
    plt.savefig('Total_loss.png') 

    plt.figure(2)
    plt.title('Reconstruction Loss')
    plt.plot(vae_r_loss, label='Train loss')
    plt.plot(vae_val_r_loss, label='Val loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.savefig('Reconstruction_loss.png') 

    plt.figure(3)
    plt.title('KL Loss')
    plt.plot(vae_kl_loss, label='Train loss')
    plt.plot(vae_val_kl_loss, label='Val loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.savefig('KL_loss.png') 

    plt.figure(4)
    plt.title('Correlation Loss')
    plt.plot(vae_c_loss, label='Train loss')
    plt.plot(vae_val_c_loss, label='Val loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.savefig('Correlation_loss.png') 


  def train_step(self, data, epoch, corr_thres, weight):  
    flag = 0
    with tf.GradientTape() as en_tape, tf.GradientTape() as de_tape:
      z_mean, z_log_var, z = self.encoder(data)
      reconstruction = self.decoder(z)
      
      if epoch < corr_thres:
        t_loss, r_loss, kl_loss = self.EMBEDTEXTNETLoss(data, reconstruction, z_mean, z_log_var, epoch, corr_thres, weight)
      else: 
        t_loss, r_loss, kl_loss, c_loss = self.EMBEDTEXTNETLoss(data, reconstruction, z_mean, z_log_var, epoch, corr_thres, weight)
        flag = 1


    gradients_of_encoder = en_tape.gradient(t_loss, self.encoder.trainable_variables)
    gradients_of_decoder = de_tape.gradient(t_loss, self.decoder.trainable_variables)

    self.encoder_optimizer.apply_gradients(zip(gradients_of_encoder, self.encoder.trainable_variables)) # Optimizer for encoder 
    self.decoder_optimizer.apply_gradients(zip(gradients_of_decoder, self.decoder.trainable_variables)) # Optimizer for decoder

    if flag == 0:
      return t_loss, r_loss, kl_loss
    else:
      return t_loss, r_loss, kl_loss, c_loss

        
  def test_step(self, data, epoch, corr_thres, weight):  
    flag = 0

    z_mean, z_log_var, z = self.encoder.predict(data)
    reconstruction = self.decoder(z, training=False)
    if epoch < corr_thres:
      t_loss, r_loss, kl_loss = self.EMBEDTEXTNETLoss(data, reconstruction, z_mean, z_log_var, epoch, corr_thres, weight)
    else: 
      t_loss, r_loss, kl_loss, c_loss = self.EMBEDTEXTNETLoss(data, reconstruction, z_mean, z_log_var, epoch, corr_thres, weight)
      flag = 1
    

    if flag == 0:
      return t_loss, r_loss, kl_loss
    else:
      return t_loss, r_loss, kl_loss, c_loss


  def train(self, train_dataset, val_dataset, epochs, corr_thres): # Train during epoch
    t_losses = []
    r_losses = []
    kl_losses = []
    c_losses = []
    val_t_losses = []
    val_r_losses = []
    val_kl_losses = []  
    val_c_losses = []
    
    weight = 1
    batch_r_w = 0
    batch_kl_w = 0

    for epoch in range(epochs): 
      start = time.time()
      for data_batch in train_dataset:        
        if epoch == 0:
          w_t_loss, w_r_loss, w_kl_loss = self.test_step(data_batch, epoch, corr_thres, weight)
          batch_r_w += w_r_loss
          batch_kl_w += w_kl_loss        
        else:
          if epoch < corr_thres:
            t_loss, r_loss, kl_loss = self.train_step(data_batch, epoch, corr_thres, weight)
          else:        
            t_loss, r_loss, kl_loss, c_loss = self.train_step(data_batch, epoch, corr_thres, weight)

      for data_batch in val_dataset:     
        if epoch != 0:
          if epoch < corr_thres:
            val_t_loss, val_r_loss, val_kl_loss = self.test_step(data_batch, epoch, corr_thres, weight)
          else:      
            val_t_loss, val_r_loss, val_kl_loss, val_c_loss = self.test_step(data_batch, epoch, corr_thres, weight)

      if epoch ==0:
        thres = batch_r_w / len(train_dataset)
        weight = (batch_r_w / batch_kl_w)
        if thres < 0.1: 
          weight *= 10
          print('Below threshold')

        else:
          weight *= 0.3 
          print('Above threshold')

      else:
        t_losses.append(t_loss)
        r_losses.append(r_loss)
        kl_losses.append(kl_loss)    
        val_t_losses.append(val_t_loss)
        val_r_losses.append(val_r_loss)
        val_kl_losses.append(val_kl_loss)
        
        if epoch >= corr_thres:
          c_losses.append(c_loss)
          val_c_losses.append(val_c_loss)  

      
      print ('Time for epoch {} is {:.2f} sec'.format(epoch + 1, time.time()-start))


    return t_losses, r_losses, kl_losses, c_losses, val_t_losses, val_r_losses, val_kl_losses, val_c_losses



  def EMBEDTEXTNETLoss(self, data, reconstruction, z_mean, z_log_var, epoch, corr_thres, weight):
    kl_loss = 1 + z_log_var - tf.square(z_mean) - tf.exp(z_log_var)
    kl_loss = tf.reduce_mean(kl_loss)
    kl_loss *= -0.5


    if epoch == 0:
      reconstruction_loss = tf.reduce_mean(keras.losses.mean_squared_error(data, reconstruction))
      total_loss = reconstruction_loss + kl_loss

      return total_loss, reconstruction_loss, kl_loss

    else:    
      if epoch < corr_thres:      
        reconstruction_loss = tf.reduce_mean(keras.losses.mean_squared_error(data, reconstruction))
        reconstruction_loss *= weight 
        total_loss = reconstruction_loss + kl_loss

        return total_loss, reconstruction_loss, kl_loss
        
      else:
        reconstruction_loss = tf.reduce_mean(keras.losses.mean_squared_error(data, reconstruction))
        reconstruction_loss *= weight 
        
        corr_loss = self.correlationLoss(reconstruction, data)    

        total_loss = reconstruction_loss + kl_loss + corr_loss

      return total_loss, reconstruction_loss, kl_loss, corr_loss
    

  def correlationLoss(self, reconstruction, original):
    Lambda = 0.01
    y1 = reconstruction
    y2 = original
    y1_mean = K.mean(y1, axis=0)
    y1_centered = y1 - y1_mean
    y2_mean = K.mean(y2, axis=0)
    y2_centered = y2 - y2_mean
    corr_nr = K.sum(y1_centered * y2_centered, axis=0) 
    corr_dr1 = K.sqrt(K.sum(y1_centered * y1_centered, axis=0) + 1e-8)
    corr_dr2 = K.sqrt(K.sum(y2_centered * y2_centered, axis=0) + 1e-8)
    corr_dr = corr_dr1 * corr_dr2
    corr = corr_nr / corr_dr 
    return K.sum(corr) * Lambda

def main(args):
  train_embed = np.load(args.train_embed)
  test_embed = np.load(args.test_embed)
  test_txt = np.load(args.test_txt)

  model = EMBEDTEXTNETModel(train_embed, args.target_txt, args.target_dim, args.epoch, args.batch_size, args.learning_rate, args.corr_thres)
  model.EMBEDTEXTNET_train()

  _, _, dim_reduc_embed = model.encoder.predict(np.reshape(test_embed, [test_embed.shape[0], test_embed.shape[1], 1, 1]))
        
  if args.target_txt == 'word':
    tmp_embeddings = {}
    embedding_file = open('reduced_embedding.txt', 'w')
    for i, x in enumerate(test_txt):
      tmp_embeddings[x] = dim_reduc_embed[i]
      embedding_file.write("%s\t" % x)
      for t in tmp_embeddings[x]:
        embedding_file.write("%f\t" % t)        
      embedding_file.write("\n")

    embedding_file.close()

  else :
    test_dict = {}
    loc = 0
    for sent in test_txt:
      if sent not in test_dict.keys():
        test_dict[sent] = [dim_reduc_embed[loc]]
      else:
        if args.target_txt == 'sentence': 
          test_dict[sent].append(dim_reduc_embed[loc])
      loc +=1 

    np.save('reduced_embedding', test_dict) 

if __name__=="__main__":
    parser = argparse.ArgumentParser(
        description='Dimension Reduction with EmbedTextNet',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--train-embed', type=str, required=True, help='Embedding of train set.')       
    parser.add_argument('--test-embed', type=str, required=True, help='Embedding of test set.')
    parser.add_argument('--test-txt', type=str, required=True, help='Text of test set.')    
    
    parser.add_argument('--target-txt', type=str, required=True, help='Choose applications: word / sentence / msetence (multilingual sentence)')
    parser.add_argument('--target-dim', type=int, required=True, help='Target reduced dimension')

    parser.add_argument('--epoch', type=int, default = 30, help='Number of epochs used in EmbedTextNet')
    parser.add_argument('--batch-size', type=int, default = 32, help='Batch size used in EmbedTextNet')
    parser.add_argument('--learning-rate', type=float, default = 2e-3, help='Learning rate used in EmbedTextNet')
    parser.add_argument('--corr-thres', type=int, default = 5, help='The point when correlation loss is considered')

    args = parser.parse_args()



    main(args)





